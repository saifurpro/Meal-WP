<?php 
// Silence is golden.